"use strict";

let highscore = 0;
let secretNumber;
let score;

function random() {
  secretNumber = Math.trunc(Math.random() * 20) + 1;
  score = 20;
}
function display(msg) {
  document.querySelector(".message").textContent = msg;
}
function scoreSet(mesag) {
  document.querySelector(".score").textContent = mesag;
}
function setReset(color, fontSize, width) {
  document.querySelector("body").style.backgroundColor = color;
  document.querySelector(".number").style.fontSize = fontSize;
  document.querySelector(".number").style.width = width;
}
random();

document.querySelector(".check").addEventListener("click", function () {
  const guess = Number(document.querySelector(".guess").value);

  if (!guess) {
    display("🛑 No number ");
  } else if (guess === secretNumber) {
    display("🎉  Correct number!  🎉");
    setReset("#60b347", "6rem", "30rem");
    document.querySelector(".number").textContent = secretNumber;

    if (score > highscore) {
      highscore = score;
      document.querySelector(".highscore").textContent = highscore;
    }
  } else if (guess !== secretNumber) {
    if (score > 1) {
      display(guess > secretNumber ? "📈 Too high " : "📉 Too low");
      score--;
      scoreSet(score);
    } else {
      display(" 💀 You lost ...");
      scoreSet(0);
    }
  }
});

document.querySelector(".again").addEventListener("click", function () {
  random();
  setReset("#222", "6rem", "15rem");
  scoreSet(score);
  display("Start guessing...");
  document.querySelector(".number").textContent = "?";
  document.querySelector(".guess").value = null;
});